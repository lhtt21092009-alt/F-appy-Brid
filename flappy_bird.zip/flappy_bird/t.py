# File: main.py (Thay thế toàn bộ nội dung file hiện tại)

import pygame
import random
import sys
import os
import math # Cần thiết cho các phiên bản sau này, nên giữ lại

# --------- CẤU HÌNH CHUNG ---------
WIDTH, HEIGHT = 400, 600
FPS = 60
ICON_SIZE = 35 

# Bird config
BIRD_X = 80
BIRD_RADIUS = 16
GRAVITY = 0.45
JUMP_V = -8.5

# Pipe config
PIPE_WIDTH = 70
PIPE_GAP_MIN = 120
PIPE_GAP_MAX = 180
PIPE_SPEED = 2.5
PIPE_DISTANCE_MIN = 200
PIPE_DISTANCE_MAX = 320

# Ground config
GROUND_HEIGHT = 40 
GROUND_Y = HEIGHT - GROUND_HEIGHT

# File names
HIGH_SCORE_FILE = "highscore.txt"

# --- ĐƯỜNG DẪN ÂM THANH ---
BGM_FILE = "assets/sounds/bgm.mp3" 
JUMP_SOUND_FILE = "assets/sounds/jump.wav"
SCORE_SOUND_FILE = "assets/sounds/score.wav"

# --- ĐƯỜNG DẪN HÌNH ẢNH ---
# THAY ĐỔI: Dùng thư mục thay vì một file duy nhất để dễ dàng mở rộng
BIRD_IMAGE_DIR = "assets/image/bird/" 
BG_IMAGE_FILE = "assets/image/bg.png" 
SPEAKER_ON_FILE = "assets/image/speaker_on.png"
SPEAKER_OFF_FILE = "assets/image/speaker_off.png"
PAUSE_ICON_FILE = "assets/image/pause_icon.png"
PLAY_ICON_FILE = "assets/image/play_icon.png"

# --------- HỖ TRỢ (load/save settings) Giữ nguyên ---------
def load_settings(path=HIGH_SCORE_FILE):
    hs = 0
    bgm_and_effects_on = True
    try:
        with open(path, "r") as f:
            lines = f.readlines()
            if len(lines) > 0:
                hs = int(lines[0].strip())
            if len(lines) > 1:
                bgm_and_effects_on = (int(lines[1].strip()) == 1)
            return hs, bgm_and_effects_on
    except:
        return hs, bgm_and_effects_on 

def save_settings(score, bgm_and_effects_on, path=HIGH_SCORE_FILE):
    bgm_state = 1 if bgm_and_effects_on else 0
    try:
        with open(path, "w") as f:
            f.write(str(score) + "\n")
            f.write(str(bgm_state) + "\n")
    except Exception as e:
        print("Không lưu được cài đặt:", e)

# --- HÀM TẢI ẢNH CHIM (KHÔI PHỤC) ---
def load_bird_images(dir_path, bird_radius):
    images = []
    # Quét tất cả file .png trong thư mục
    try:
        if os.path.exists(dir_path):
            bird_files = sorted([f for f in os.listdir(dir_path) if f.endswith('.png')])
            for filename in bird_files:
                file_path = os.path.join(dir_path, filename)
                img = pygame.image.load(file_path).convert_alpha()
                target_size = bird_radius * 2
                img = pygame.transform.scale(img, (target_size, target_size))
                images.append(img)
            # Nếu không tìm thấy file, sử dụng ảnh mặc định
            if not images:
                # Dùng ảnh mặc định tạm thời nếu thư mục có nhưng rỗng
                default_img = pygame.Surface((bird_radius * 2, bird_radius * 2), pygame.SRCALPHA)
                pygame.draw.circle(default_img, (255, 220, 0), (bird_radius, bird_radius), bird_radius)
                images.append(default_img)
        else:
            # Dùng ảnh mặc định nếu thư mục không tồn tại
            default_img = pygame.Surface((bird_radius * 2, bird_radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(default_img, (255, 220, 0), (bird_radius, bird_radius), bird_radius)
            images.append(default_img)
            
    except Exception as e:
        print(f"Lỗi tải ảnh chim: {e}. Dùng ảnh mặc định.")
        default_img = pygame.Surface((bird_radius * 2, bird_radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(default_img, (255, 220, 0), (bird_radius, bird_radius), bird_radius)
        images.append(default_img)
        
    return images


# --------- LỚP VẬT (Bird, Pipe) Giữ nguyên ---------
class Bird:
    def __init__(self, image):
        self.x = BIRD_X
        self.y = HEIGHT // 2
        self.vel = 0.0
        self.radius = BIRD_RADIUS
        self.alive = True
        self.rotation = 0.0
        
        self.original_image = image
        self.image = image
        self.rect = self.image.get_rect(center=(self.x, self.y))

    def jump(self):
        self.vel = JUMP_V

    def update(self):
        self.vel += GRAVITY
        self.y += self.vel
        
        # Chỉ xoay chim khi nó đang bay/rơi
        self.rotation = max(-30, min(60, -self.vel * 4))
        self.image = pygame.transform.rotate(self.original_image, self.rotation)
        
        self.rect = self.image.get_rect(center=(int(self.x), int(self.y)))

        if self.y - self.radius < 0:
            self.y = self.radius
            self.vel = 0
        if self.y + self.radius > GROUND_Y:
            self.y = GROUND_Y - self.radius
            self.alive = False

    def draw(self, surf):
        surf.blit(self.image, self.rect)

    def get_rect(self):
        return pygame.Rect(self.x - self.radius, self.y - self.radius, self.radius*2, self.radius*2)

class Pipe:
    def __init__(self, x):
        self.x = x
        gap = random.randint(PIPE_GAP_MIN, PIPE_GAP_MAX)
        top_h = random.randint(60, GROUND_Y - 60 - gap)
        self.top = pygame.Rect(self.x, 0, PIPE_WIDTH, top_h)
        self.bottom = pygame.Rect(self.x, top_h + gap, PIPE_WIDTH, GROUND_Y - (top_h + gap)) 
        self.passed = False

    def update(self):
        self.x -= PIPE_SPEED
        self.top.x = int(self.x)
        self.bottom.x = int(self.x)

    def draw(self, surf):
        pygame.draw.rect(surf, (34,139,34), self.top)
        pygame.draw.rect(surf, (34,139,34), self.bottom)
        pygame.draw.rect(surf, (20,100,20), (self.top.x, self.top.height - 8, PIPE_WIDTH, 8))
        pygame.draw.rect(surf, (20,100,20), (self.bottom.x, self.bottom.y, PIPE_WIDTH, 8))

    def off_screen(self):
        return self.x + PIPE_WIDTH < -10

# --------- HÀM HỖ TRỢ Giữ nguyên ---------
def check_collision(bird, pipes):
    bird_rect = bird.get_rect()
    for p in pipes:
        if bird_rect.colliderect(p.top) or bird_rect.colliderect(p.bottom):
            return True
    if bird_rect.bottom >= GROUND_Y:
        return True
    return not bird.alive

def make_initial_pipes():
    pipes = []
    x = WIDTH + 50
    while x < WIDTH + 700:
        pipes.append(Pipe(x))
        x += random.randint(PIPE_DISTANCE_MIN, PIPE_DISTANCE_MAX)
    return pipes

# --------- MAIN GAME (Đã CHỈNH KHOẢNG CÁCH MŨI TÊN SÁT CHIM) ---------
def main():
    # Khởi tạo Pygame Mixer
    try:
        pygame.mixer.pre_init(44100, -16, 2, 512)
    except Exception as e:
        print(f"Lỗi cấu hình Pygame Mixer: {e}")
        
    pygame.init()
    
    mixer_ok = pygame.mixer.get_init() is not None
    if not mixer_ok:
        print("Lỗi: Không thể khởi tạo Pygame Mixer. Âm thanh sẽ bị tắt.")
    
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Flappy Bird")
    clock = pygame.time.Clock()

    # font
    font = pygame.font.SysFont("Arial", 28)
    big_font = pygame.font.SysFont("Arial", 48, bold=True)
    medium_font = pygame.font.SysFont("Arial", 36)

    # --- LOAD HÌNH ẢNH CHIM (Dùng hàm mới) ---
    bird_images = load_bird_images(BIRD_IMAGE_DIR, BIRD_RADIUS)
    
    bg_image = None
    try:
        if os.path.exists(BG_IMAGE_FILE):
            bg_image = pygame.image.load(BG_IMAGE_FILE).convert()
            bg_image = pygame.transform.scale(bg_image, (WIDTH, HEIGHT))
        else:
            raise pygame.error("Background image file not found.")
    except pygame.error as e:
        pass
    
    icons = {}
    icon_files = {
        'speaker_on': SPEAKER_ON_FILE, 'speaker_off': SPEAKER_OFF_FILE,
        'pause': PAUSE_ICON_FILE, 'play': PLAY_ICON_FILE
    }
    for name, file in icon_files.items():
        try:
            if os.path.exists(file):
                img = pygame.image.load(file).convert_alpha()
                icons[name] = pygame.transform.scale(img, (ICON_SIZE, ICON_SIZE))
            else:
                raise pygame.error(f"Icon file {file} not found.")
        except pygame.error as e:
            icons[name] = pygame.Surface((ICON_SIZE, ICON_SIZE), pygame.SRCALPHA)
            pygame.draw.rect(icons[name], (255, 0, 255), icons[name].get_rect()) 

    # --- LOAD SOUNDS ---
    jump_sound = None; score_sound = None
    bgm_loaded = False
    
    if mixer_ok:
        try:
            if os.path.exists(JUMP_SOUND_FILE): 
                jump_sound = pygame.mixer.Sound(JUMP_SOUND_FILE)
            if os.path.exists(SCORE_SOUND_FILE): 
                score_sound = pygame.mixer.Sound(SCORE_SOUND_FILE)
            if os.path.exists(BGM_FILE): 
                pygame.mixer.music.load(BGM_FILE)
                bgm_loaded = True
        except Exception as e:
            print(f"Lỗi tải file âm thanh: {e}. Âm thanh bị tắt.")
            mixer_ok = False 

    # Load highscore và trạng thái BGM/FX
    highscore, bgm_and_effects_on = load_settings() 
    if bgm_and_effects_on and bgm_loaded and mixer_ok:
        pygame.mixer.music.play(-1)

    # game state
    current_bird_index = 0
    current_bird_image = bird_images[current_bird_index]
    bird = Bird(current_bird_image)
    pipes = [] 
    score = 0
    running = True
    
    # TRẠNG THÁI GAME: START_MENU, PLAYING, GAME_OVER, PAUSED
    GAME_STATE = "START_MENU" 

    bg_color = (135, 206, 235)
    
    # === KHU VỰC CẢM ỨNG (BUTTON RECTS) ===
    BUTTON_PADDING = 10
    BGM_BUTTON_RECT = pygame.Rect(WIDTH - ICON_SIZE - BUTTON_PADDING, BUTTON_PADDING, ICON_SIZE, ICON_SIZE)
    PAUSE_BUTTON_RECT = pygame.Rect(BGM_BUTTON_RECT.left - ICON_SIZE - BUTTON_PADDING, BUTTON_PADDING, ICON_SIZE, ICON_SIZE)
    
    # === RECTS CHO START MENU (ĐÃ CHỈNH LẠI VỊ TRÍ MŨI TÊN SÁT CHIM) ===
    START_TEXT_Y = HEIGHT // 2 - 100
    BIRD_SELECTION_Y = HEIGHT // 2
    ARROW_SIZE = 30
    
    # Nút mũi tên chọn chim (SÁT CHIM: 20px cách)
    # Tọa độ X mới: WIDTH//2 - 66
    LEFT_ARROW_RECT = pygame.Rect(WIDTH//2 - 66, BIRD_SELECTION_Y - ARROW_SIZE//2, ARROW_SIZE, ARROW_SIZE)
    # Tọa độ X mới: WIDTH//2 + 36
    RIGHT_ARROW_RECT = pygame.Rect(WIDTH//2 + 36, BIRD_SELECTION_Y - ARROW_SIZE//2, ARROW_SIZE, ARROW_SIZE)
    
    # Rect để hiển thị chim (sẽ đặt chim ở giữa)
    BIRD_DISPLAY_RECT = pygame.Rect(WIDTH//2 - 33 - BIRD_RADIUS, BIRD_SELECTION_Y - BIRD_RADIUS, BIRD_RADIUS*2, BIRD_RADIUS*2)

    
    # Rect cho nút START
    START_BUTTON_RECT = pygame.Rect(WIDTH//2 - 70, HEIGHT//2 + 80, 140, 50)
    
    # --- ĐỊNH NGHĨA MÀU SẮC MỚI ---
    COLOR_TITLE = (255, 220, 0)      # Vàng cho tiêu đề
    COLOR_HIGHSCORE = (255, 255, 255) # Trắng cho highscore
    COLOR_GAMEOVER = (255, 100, 100)  # Đỏ nhạt cho Game Over
    COLOR_INSTRUCTION = (255, 255, 255) # Trắng cho hướng dẫn
    
    while running:
        dt = clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            # === XỬ LÝ CẢM ỨNG/NHẤP CHUỘT (MOUSEBUTTONDOWN) ===
            if event.type == pygame.MOUSEBUTTONDOWN:
                click_pos = event.pos
                
                # 1. Nhấp vào Nút BGM/FX (Luôn có)
                if BGM_BUTTON_RECT.collidepoint(click_pos) and mixer_ok:
                    bgm_and_effects_on = not bgm_and_effects_on 
                    
                    if bgm_and_effects_on: # BẬT (ON)
                        if bgm_loaded:
                            if pygame.mixer.music.get_busy() == 0:
                                pygame.mixer.music.play(-1)
                    else: # TẮT (OFF)
                        if bgm_loaded:
                             pygame.mixer.music.stop() 
                        
                    save_settings(highscore, bgm_and_effects_on)

                # --- START MENU LOGIC ---
                if GAME_STATE == "START_MENU":
                    # Chọn chim
                    if LEFT_ARROW_RECT.collidepoint(click_pos):
                        current_bird_index = (current_bird_index - 1) % len(bird_images)
                        current_bird_image = bird_images[current_bird_index]
                        bird = Bird(current_bird_image) # Cập nhật Bird object
                    elif RIGHT_ARROW_RECT.collidepoint(click_pos):
                        current_bird_index = (current_bird_index + 1) % len(bird_images)
                        current_bird_image = bird_images[current_bird_index]
                        bird = Bird(current_bird_image) # Cập nhật Bird object
                    
                    # Nút START Game
                    elif START_BUTTON_RECT.collidepoint(click_pos):
                        GAME_STATE = "PLAYING"
                        pipes = make_initial_pipes()
                        # Nhảy lần đầu
                        bird.jump()
                        if jump_sound and mixer_ok and bgm_and_effects_on: 
                            jump_sound.play()
                        
                # --- PLAYING / PAUSED / GAME OVER LOGIC ---
                elif GAME_STATE == "PLAYING" or GAME_STATE == "PAUSED":
                    
                    # 2. Nhấp vào Nút Pause/Resume
                    if PAUSE_BUTTON_RECT.collidepoint(click_pos):
                        if GAME_STATE == "PLAYING":
                            GAME_STATE = "PAUSED"
                        elif GAME_STATE == "PAUSED":
                            GAME_STATE = "PLAYING"
                            
                    # 3. Nhấp để Nhảy (Chỉ khi đang PLAYING)
                    elif GAME_STATE == "PLAYING":
                        bird.jump()
                        if jump_sound and mixer_ok and bgm_and_effects_on: 
                            jump_sound.play()
                        
                # --- GAME OVER LOGIC ---
                elif GAME_STATE == "GAME_OVER":
                    # 4. Nhấp để Restart (Chuyển về Menu)
                    GAME_STATE = "START_MENU"
                    bird = Bird(current_bird_image) # Khởi tạo chim với ảnh đã chọn
                    pipes = []
                    score = 0 
                    if jump_sound and mixer_ok:
                        jump_sound.stop()
                    
                    if bgm_and_effects_on and bgm_loaded and mixer_ok:
                        if pygame.mixer.music.get_busy() == 0:
                            pygame.mixer.music.play(-1)
                            
            # Giữ lại phím tắt dự phòng (nhảy, ESC)
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_SPACE, pygame.K_UP):
                    if GAME_STATE == "PLAYING":
                        bird.jump()
                        if jump_sound and mixer_ok and bgm_and_effects_on:
                            jump_sound.play()
                    elif GAME_STATE == "START_MENU":
                        # Phím SPACE/UP để bắt đầu từ START MENU
                        GAME_STATE = "PLAYING"
                        pipes = make_initial_pipes()
                        bird.jump()
                        if jump_sound and mixer_ok and bgm_and_effects_on: 
                            jump_sound.play()
                            
                if event.key == pygame.K_ESCAPE:
                    running = False

        # === UPDATE LOGIC ===
        if GAME_STATE == "PLAYING":
            # update
            bird.update()
            for p in pipes:
                p.update()

            pipes = [p for p in pipes if not p.off_screen()]

            # Respawn pipes
            if len(pipes) == 0 or (pipes[-1].x < WIDTH - random.randint(PIPE_DISTANCE_MIN-50, PIPE_DISTANCE_MAX-50)):
                pipes.append(Pipe(WIDTH + random.randint(0, 80)))

            # scoring:
            for p in pipes:
                if (not p.passed) and (p.x + PIPE_WIDTH < bird.x):
                    p.passed = True
                    score += 1
                    if score_sound and mixer_ok and bgm_and_effects_on:
                        score_sound.play()
                    if score > highscore:
                        highscore = score
                        save_settings(highscore, bgm_and_effects_on)

            # collision check
            if check_collision(bird, pipes):
                GAME_STATE = "GAME_OVER"
                if score > highscore:
                    highscore = score
                save_settings(highscore, bgm_and_effects_on)
        
        elif GAME_STATE == "START_MENU":
            # Chim đứng yên tuyệt đối, chính giữa giữa 2 mũi tên
            bird_center_x = (LEFT_ARROW_RECT.right + RIGHT_ARROW_RECT.left) // 2
            bird_center_y = BIRD_SELECTION_Y

            bird.x = bird_center_x
            bird.y = bird_center_y
            bird.alive = True

            # Cập nhật lại rect để vẽ đúng chỗ
            bird.rect = bird.image.get_rect(center=(int(bird.x), int(bird.y)))

            
        # ---------- DRAW ----------
        if bg_image:
            screen.blit(bg_image, (0, 0))
        else:
            screen.fill(bg_color)

        # ground: VẼ THANH NGANG BÊN DƯỚI
        ground_rect = pygame.Rect(0, GROUND_Y, WIDTH, GROUND_HEIGHT)
        pygame.draw.rect(screen, (222,184,135), ground_rect)

        # draw pipes (chỉ vẽ khi đang chơi hoặc game over)
        if GAME_STATE != "START_MENU":
            for p in pipes:
                p.draw(screen)

        # bird
        bird.draw(screen)

        # HUD: score + highscore (chỉ vẽ khi đang chơi/dừng/kết thúc)
        if GAME_STATE != "START_MENU":
            score_surf = font.render(f"Score: {score}", True, (255,255,255))
            hs_surf = font.render(f"High: {highscore}", True, (255,255,255))
            screen.blit(score_surf, (10, 10))
            screen.blit(hs_surf, (10, 40))
        
        # === VẼ NÚT BIỂU TƯỢNG (BGM LUÔN HIỂN THỊ) ===
        
        # 1. Nút BGM (Loa)
        bgm_icon = icons['speaker_on'] if bgm_and_effects_on else icons['speaker_off']
        screen.blit(bgm_icon, BGM_BUTTON_RECT.topleft)

        # 2. Nút Pause/Resume (chỉ hiển thị khi đang chơi/dừng)
        if GAME_STATE == "PLAYING" or GAME_STATE == "PAUSED":
            pause_icon = icons['pause'] if GAME_STATE == "PLAYING" else icons['play']
            screen.blit(pause_icon, PAUSE_BUTTON_RECT.topleft)

        # --- HIỂN THỊ TRẠNG THÁI ---
        if GAME_STATE == "START_MENU":
            # Tiêu đề
            txt = big_font.render("FLAPPY BIRD", True, COLOR_TITLE) 
            screen.blit(txt, (WIDTH//2 - txt.get_width()//2, START_TEXT_Y))
            
            # Highscore (ĐÃ ĐIỀU CHỈNH VỊ TRÍ Y LÊN CAO HƠN)
            NEW_HIGHSCORE_Y = START_TEXT_Y + 50 
            hs_surf = font.render(f"High Score: {highscore}", True, COLOR_HIGHSCORE) 
            screen.blit(hs_surf, (WIDTH//2 - hs_surf.get_width()//2, NEW_HIGHSCORE_Y))
            
            # Vẽ mũi tên chọn chim (Sử dụng Rects đã điều chỉnh)
            pygame.draw.polygon(screen, (255, 255, 255), [(LEFT_ARROW_RECT.left, LEFT_ARROW_RECT.centery), 
                                                          (LEFT_ARROW_RECT.right, LEFT_ARROW_RECT.top), 
                                                          (LEFT_ARROW_RECT.right, LEFT_ARROW_RECT.bottom)])
            pygame.draw.polygon(screen, (255, 255, 255), [(RIGHT_ARROW_RECT.right, RIGHT_ARROW_RECT.centery), 
                                                          (RIGHT_ARROW_RECT.left, RIGHT_ARROW_RECT.top), 
                                                          (RIGHT_ARROW_RECT.left, RIGHT_ARROW_RECT.bottom)])
            
            # Vẽ nút START
            pygame.draw.rect(screen, (0, 150, 0), START_BUTTON_RECT, 0, 10)
            start_txt = medium_font.render("START", True, (255, 255, 255))
            screen.blit(start_txt, (START_BUTTON_RECT.centerx - start_txt.get_width()//2, 
                                    START_BUTTON_RECT.centery - start_txt.get_height()//2))
            
        # Game over overlay
        elif GAME_STATE == "GAME_OVER":
            overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay.fill((0,0,0,140))
            screen.blit(overlay, (0,0))
            txt = big_font.render("Game Over", True, COLOR_GAMEOVER) 
            sub = font.render("Click anywhere to Restart", True, COLOR_INSTRUCTION) 
            screen.blit(txt, (WIDTH//2 - txt.get_width()//2, HEIGHT//2 - 50))
            screen.blit(sub, (WIDTH//2 - sub.get_width()//2, HEIGHT//2 + 10))
            
        # Pause overlay
        elif GAME_STATE == "PAUSED":
            overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay.fill((0,0,0,100))
            screen.blit(overlay, (0,0))
            txt = big_font.render("PAUSED", True, (255, 255, 0)) 
            sub = medium_font.render("Click PLAY button to resume", True, (255,255,255)) 
            screen.blit(txt, (WIDTH//2 - txt.get_width()//2, HEIGHT//2 - 40))
            screen.blit(sub, (WIDTH//2 - sub.get_width()//2, HEIGHT//2 + 20))


        pygame.display.flip()

    save_settings(highscore, bgm_and_effects_on)
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
